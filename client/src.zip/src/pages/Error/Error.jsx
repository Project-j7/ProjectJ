export default function Error(){
    return(
        <div>
            <h1 >Opps You Hit an Error!!!!!!!!</h1>
        </div>
    );
}