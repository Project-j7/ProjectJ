import Login from "../../components/login/index"

export default function LoginPage() {
    return (
        <Login/>
    );
}