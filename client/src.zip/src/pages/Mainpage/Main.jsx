import Main from "../../components/mainpage";

export default function SignupPage() {
    return (
        <Main/>
    );
}