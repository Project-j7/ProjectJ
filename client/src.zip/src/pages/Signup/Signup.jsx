import Signup from "../../components/signup/index"

export default function SignupPage() {
    return (
        <Signup/>
    );
}